create function update_product_price() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Заполняем поле product_price из таблицы products
    SELECT price INTO NEW.product_price FROM products WHERE id = NEW.product_id;
    -- Заполняем поле product_name из таблицы products
    SELECT title INTO NEW.product_name FROM products WHERE id = NEW.product_id;
    RETURN NEW;
END;
$$;

alter function update_product_price() owner to postgres;

