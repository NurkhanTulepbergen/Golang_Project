create function update_follow() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the followed_products for the user
    INSERT INTO follow (user_id, user_name, followed_products)
    VALUES (
               NEW.user_id,
               (SELECT name FROM users WHERE id = NEW.user_id),
               (
                   SELECT jsonb_agg(
                                  jsonb_build_object(
                                          'product_id', product_id,
                                          'product_name', product_name,
                                          'product_description', product_description,
                                          'product_price', product_price
                                  )
                          )
                   FROM follow_list
                   WHERE user_id = NEW.user_id
               )
           )
    ON CONFLICT (user_id) DO UPDATE
        SET followed_products = EXCLUDED.followed_products;

    RETURN NEW;
END;
$$;

alter function update_follow() owner to postgres;

