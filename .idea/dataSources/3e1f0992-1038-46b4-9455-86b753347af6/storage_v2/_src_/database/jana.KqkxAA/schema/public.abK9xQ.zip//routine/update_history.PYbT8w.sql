create function update_history() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the followed_products for the user
    INSERT INTO history (user_id, user_name, orders_list)
    VALUES (
               NEW.user_id,
               (SELECT name FROM users WHERE id = NEW.user_id),
               (
                   SELECT jsonb_agg(
                                  jsonb_build_object(
                                          'order_id', id,
                                          'user_id', user_id,
                                          'total_amount', total_amount,
                                          'delivery_addr', delivery_addr,
                                          'status', status
                                  )
                          )
                   FROM orders
                   WHERE user_id = NEW.user_id
               )
           )
    ON CONFLICT (user_id) DO UPDATE
        SET orders_list = EXCLUDED.orders_list;

    RETURN NEW;
END;
$$;

alter function update_history() owner to postgres;

