create function update_order_total() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE orders
    SET total_amount = (
        SELECT SUM(product_price * quantity)
        FROM order_helper
        WHERE order_id = NEW.order_id
    )
    WHERE id = NEW.order_id;

    RETURN NEW;
END;
$$;

alter function update_order_total() owner to postgres;

